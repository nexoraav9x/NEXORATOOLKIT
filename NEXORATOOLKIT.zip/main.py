import os

def banner():
    os.system("clear")
    print("="*50)
    print("          🔥 NEXORATOOLKIT 🔥")
    print("     Ethical Hacking Toolkit for Termux")
    print("="*50)

def menu():
    banner()
    print("""
[1] Port Scanner
[2] IP Tracker
[3] Admin Panel Finder
[4] MAC Address Changer
[5] Hash Cracker
[6] Exit
""")
    choice = input("Enter your choice: ")

    if choice == '1':
        os.system("python modules/port_scanner.py")
    elif choice == '2':
        os.system("python modules/ip_tracker.py")
    elif choice == '3':
        os.system("python modules/admin_finder.py")
    elif choice == '4':
        os.system("python modules/mac_changer.py")
    elif choice == '5':
        os.system("python modules/hash_cracker.py")
    elif choice == '6':
        print("Exiting... Bye!")
        exit()
    else:
        print("Invalid choice. Try again.")

if __name__ == "__main__":
    menu()