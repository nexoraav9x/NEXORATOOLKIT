import requests

def admin_panel_finder():
    print("="*40)
    print("     🧠 Admin Panel Finder")
    print("="*40)

    target = input("Enter website URL (e.g., https://example.com): ").strip()
    if not target.startswith("http"):
        target = "http://" + target

    try:
        with open("wordlists/admin-panels.txt", "r") as wordlist:
            for path in wordlist:
                path = path.strip()
                url = f"{target}/{path}"
                try:
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        print(f"[✔] Found Admin Panel: {url}")
                except requests.exceptions.RequestException:
                    pass
        print("\n[✓] Scanning complete.")
    except FileNotFoundError:
        print("[-] Wordlist not found. Please make sure 'admin-panels.txt' exists.")

if __name__ == "__main__":
    admin_panel_finder()