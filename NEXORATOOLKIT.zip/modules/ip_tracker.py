import requests

def ip_tracker():
    print("="*40)
    print("         🌐 IP Tracker Tool")
    print("="*40)

    ip = input("Enter IP address or domain: ").strip()
    try:
        response = requests.get(f"http://ip-api.com/json/{ip}").json()

        if response['status'] == 'success':
            print(f"\n[+] IP: {response['query']}")
            print(f"[+] Country: {response['country']}")
            print(f"[+] Region: {response['regionName']}")
            print(f"[+] City: {response['city']}")
            print(f"[+] ISP: {response['isp']}")
            print(f"[+] Lat: {response['lat']} | Lon: {response['lon']}")
            print(f"[+] Timezone: {response['timezone']}")
        else:
            print("[-] Invalid IP or Domain.")

    except Exception as e:
        print(f"[-] Error: {e}")

if __name__ == "__main__":
    ip_tracker()