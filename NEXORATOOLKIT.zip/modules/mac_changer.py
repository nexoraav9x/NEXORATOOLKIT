import random

def generate_mac():
    return "02:%02x:%02x:%02x:%02x:%02x" % tuple(random.randint(0x00, 0xff) for _ in range(5))

def mac_changer():
    print("="*40)
    print("     🛡️ Virtual MAC Address Spoofer")
    print("="*40)

    new_mac = generate_mac()
    print(f"[+] Fake MAC Address generated: {new_mac}")
    print("Note: Real MAC change needs root access.")
    print("Use this only for spoofing/testing purpose.")

if __name__ == "__main__":
    mac_changer()