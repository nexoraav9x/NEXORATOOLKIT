import hashlib

def hash_cracker():
    print("="*40)
    print("        🔓 Hash Cracker (MD5/SHA1)")
    print("="*40)

    hash_input = input("Enter the hash: ")
    hash_type = input("Enter hash type (md5/sha1): ").lower()
    wordlist_path = input("Enter path to wordlist: ")

    try:
        with open(wordlist_path, 'r') as file:
            for word in file:
                word = word.strip()
                if hash_type == 'md5':
                    hashed = hashlib.md5(word.encode()).hexdigest()
                elif hash_type == 'sha1':
                    hashed = hashlib.sha1(word.encode()).hexdigest()
                else:
                    print("[-] Unsupported hash type.")
                    return

                if hashed == hash_input:
                    print(f"[✔] Hash cracked: {word}")
                    return
        print("[-] Hash not found in wordlist.")
    except FileNotFoundError:
        print("[-] Wordlist file not found.")

if __name__ == "__main__":
    hash_cracker()