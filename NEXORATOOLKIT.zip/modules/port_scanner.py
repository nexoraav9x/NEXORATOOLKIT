import os

def port_scanner():
    print("="*40)
    print("         🔍 Port Scanner (Nmap) ")
    print("="*40)
    target = input("Enter target IP or domain: ")
    print("\n[+] Scanning target:", target)
    os.system(f"nmap -sS -Pn {target}")

if __name__ == "__main__":
    port_scanner()