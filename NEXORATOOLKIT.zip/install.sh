#!/bin/bash

echo "Installing dependencies for NEXORATOOLKIT..."

pkg update -y
pkg install python -y
pkg install nmap -y
pip install requests

echo "[✔] All dependencies installed."
echo "[✓] Run the toolkit with: python main.py"